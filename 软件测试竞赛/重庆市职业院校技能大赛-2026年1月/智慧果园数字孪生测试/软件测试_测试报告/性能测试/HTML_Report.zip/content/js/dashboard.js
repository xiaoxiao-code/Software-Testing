/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.27510572215691, "KoPercent": 1.7248942778430925};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8733264314165892, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.8776958882854926, 500, 1500, "Sync_IoT_Data"], "isController": false}, {"data": [0.5612033195020747, 500, 1500, "Control_Request"], "isController": false}, {"data": [0.8813504823151126, 500, 1500, "AI_Chat_Request"], "isController": false}, {"data": [0.8189983669025586, 500, 1500, "Login_Request"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 56989, 983, 1.7248942778430925, 454.70267946445495, 33, 48269, 209.0, 854.0, 1364.0, 7776.120000000141, 180.28560220686862, 558.0315740873652, 86.7152058736998], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Sync_IoT_Data", 51560, 850, 1.6485647788983708, 435.70593483320545, 33, 48269, 198.0, 748.0, 1280.0, 7147.450000000088, 163.11087490193103, 522.7976696603413, 78.28486876550123], "isController": false}, {"data": ["Control_Request", 482, 117, 24.273858921161825, 1289.3506224066396, 330, 22374, 545.5, 1637.0, 2425.99999999999, 22269.89, 1.5736463213568619, 0.649776971547038, 0.8030484551249611], "isController": false}, {"data": ["AI_Chat_Request", 3110, 4, 0.12861736334405144, 455.1871382636658, 37, 19157, 212.0, 1208.0, 1259.4499999999998, 3210.7799999999997, 10.053045167588465, 2.669484649105085, 5.825733739967158], "isController": false}, {"data": ["Login_Request", 1837, 12, 0.65323897659227, 768.0751224823099, 37, 35268, 241.0, 1189.4, 1756.199999999999, 13592.159999999954, 5.900794696030375, 32.484005171426595, 1.9807987775204454], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["操作持续太长时间：他花费了1,409毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,634毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,014毫秒，但不应该超过1,000毫秒。", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["操作持续太长时间：他花费了1,434毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,092毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,233毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,476毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,015毫秒，但不应该超过1,000毫秒。", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["操作持续太长时间：他花费了1,380毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,441毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,635毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,469毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,554毫秒，但不应该超过1,000毫秒。", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["操作持续太长时间：他花费了1,522毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,492毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,641毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,013毫秒，但不应该超过1,000毫秒。", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 6, 0.6103763987792472, 0.01052834757584797], "isController": false}, {"data": ["操作持续太长时间：他花费了1,478毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了10,373毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,619毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,016毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,440毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,549毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,514毫秒，但不应该超过1,000毫秒。", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["操作持续太长时间：他花费了1,466毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,677毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,012毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,379毫秒，但不应该超过1,000毫秒。", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["操作持续太长时间：他花费了1,419毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了3,040毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,929毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,631毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,278毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,811毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.mufancloud.com:443 failed to respond", 66, 6.714140386571719, 0.11581182333432767], "isController": false}, {"data": ["操作持续太长时间：他花费了1,173毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,437毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,637毫秒，但不应该超过1,000毫秒。", 6, 0.6103763987792472, 0.01052834757584797], "isController": false}, {"data": ["操作持续太长时间：他花费了1,199毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,516毫秒，但不应该超过1,000毫秒。", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["操作持续太长时间：他花费了1,200毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,473毫秒，但不应该超过1,000毫秒。", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["操作持续太长时间：他花费了1,489毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,503毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,155毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,094毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,834毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,521毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,481毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,662毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,142毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了5,048毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["Test failed: text expected to contain /200/", 721, 73.34689725330621, 1.2651564336977312], "isController": false}, {"data": ["操作持续太长时间：他花费了5,631毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to www.mufancloud.com:443 [www.mufancloud.com/198.18.0.170] failed: Connection timed out: connect", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["操作持续太长时间：他花费了2,583毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,733毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,786毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,247毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,254毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,646毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,280毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,413毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,613毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,620毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,454毫秒，但不应该超过1,000毫秒。", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["操作持续太长时间：他花费了1,297毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了3,092毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,448毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,871毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,279毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,540毫秒，但不应该超过1,000毫秒。", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["操作持续太长时间：他花费了1,253毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 82, 8.341810783316378, 0.14388741686992226], "isController": false}, {"data": ["操作持续太长时间：他花费了1,528毫秒，但不应该超过1,000毫秒。", 2, 0.2034587995930824, 0.0035094491919493236], "isController": false}, {"data": ["操作持续太长时间：他花费了1,461毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,640毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,236毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,587毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,171毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了3,057毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了3,070毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,861毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,695毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,833毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,011毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了5,053毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,467毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,471毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,151毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,004毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,630毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了2,027毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}, {"data": ["操作持续太长时间：他花费了1,877毫秒，但不应该超过1,000毫秒。", 1, 0.1017293997965412, 0.0017547245959746618], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 56989, 983, "Test failed: text expected to contain /200/", 721, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 82, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.mufancloud.com:443 failed to respond", 66, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 6, "操作持续太长时间：他花费了1,637毫秒，但不应该超过1,000毫秒。", 6], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Sync_IoT_Data", 51560, 850, "Test failed: text expected to contain /200/", 720, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 70, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.mufancloud.com:443 failed to respond", 57, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to www.mufancloud.com:443 [www.mufancloud.com/198.18.0.170] failed: Connection timed out: connect", 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1], "isController": false}, {"data": ["Control_Request", 482, 117, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 9, "操作持续太长时间：他花费了1,637毫秒，但不应该超过1,000毫秒。", 6, "操作持续太长时间：他花费了2,014毫秒，但不应该超过1,000毫秒。", 2, "操作持续太长时间：他花费了2,015毫秒，但不应该超过1,000毫秒。", 2, "操作持续太长时间：他花费了1,554毫秒，但不应该超过1,000毫秒。", 2], "isController": false}, {"data": ["AI_Chat_Request", 3110, 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 4, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Login_Request", 1837, 12, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.mufancloud.com:443 failed to respond", 9, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 3, "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
